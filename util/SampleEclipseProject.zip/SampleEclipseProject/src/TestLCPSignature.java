import java.net.URL;
import java.util.Date;
import java.util.Random;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

public class TestLCPSignature {

	public static String generateAuthorizationHeader(String macId, String macKey,
			String contentType, String requestBody, URL lcpURL)
			throws Exception {
		// Step 1: Generate epoch time in seconds
		String ts = "" + new Date().getTime();
		ts = ts.substring(0, ts.length() - 3);

		// Step 2: Generate nonce
		byte[] noncebytes = new byte[8];
		new Random(new Date().getTime()).nextBytes(noncebytes);
		String nonce = Base64.encodeBase64String(noncebytes);

		// Step 3: Generate ext
		String ext = "";
		if (requestBody != null && contentType != null) {
			ext = DigestUtils.sha1Hex(contentType + requestBody);
		}

		// Step 4: Build normalized request string
		String normalizedRequestString = ts + "\n" + nonce + "\n" + "POST\n"
				+ lcpURL.getPath() + "\n" + lcpURL.getHost() + "\n"
				+ "443" + "\n" + ext + "\n";

		// Step 5: Base64 decode the MAC key from URL-safe alphabet
		Mac sha1_HMAC = Mac.getInstance("HmacSHA1");
		SecretKeySpec secret_key = new SecretKeySpec(Base64.decodeBase64(macKey
				.getBytes()), "HmacSHA1");
		sha1_HMAC.init(secret_key);
		String mac = Base64.encodeBase64String(sha1_HMAC
				.doFinal(normalizedRequestString.getBytes()));

		// Step 8: Build Authorization header
		StringBuffer authorizationHeader = new StringBuffer("MAC ");
		authorizationHeader.append("id=\"").append(macId).append("\", ");
		authorizationHeader.append("ts=\"").append(ts).append("\", ");
		authorizationHeader.append("nonce=\"").append(nonce).append("\", ");
		authorizationHeader.append("ext=\"").append(ext).append("\", ");
		authorizationHeader.append("mac=\"").append(mac).append("\"");

		return authorizationHeader.toString();
	}
}
